plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dvereux.vcursor"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.dvereux.vcursor"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "3"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
