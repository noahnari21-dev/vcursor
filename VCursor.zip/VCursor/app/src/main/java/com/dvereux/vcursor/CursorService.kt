package com.dvereux.vcursor

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import kotlin.math.abs

class CursorService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var cursor: CursorView? = null
    private var cursorLp: WindowManager.LayoutParams? = null
    private var toggle: TextView? = null
    private var enabled = true
    private var tx = 24
    private var ty = 24

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        refresh()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        refresh()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        removeViews()
        super.onDestroy()
    }

    private fun isLandscape() =
        resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private fun refresh() {
        removeViews()
        if (!isLandscape()) return
        if (enabled) addCursor()
        addToggle()   // added last so it stays on top
    }

    private fun removeViews() {
        cursor?.let { runCatching { wm.removeView(it) } }
        toggle?.let { runCatching { wm.removeView(it) } }
        cursor = null; cursorLp = null; toggle = null
    }

    private fun addCursor() {
        val v = CursorView(
            this,
            onStroke = { path, ms -> inject(path, ms) },
            onBack = { performGlobalAction(GLOBAL_ACTION_BACK) }
        )
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        cursor = v; cursorLp = lp
    }

    private fun addToggle() {
        val t = TextView(this).apply {
            text = if (enabled) "CURSOR ON" else "CURSOR OFF"
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(28, 14, 28, 14)
            setBackgroundColor(if (enabled) 0xCC1B5E20.toInt() else 0xCC616161.toInt())
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = tx; y = ty }

        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragged = false
        t.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y; dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (dragged || abs(dx) > 12 || abs(dy) > 12) {
                        dragged = true
                        lp.x = startX + dx.toInt(); lp.y = startY + dy.toInt()
                        tx = lp.x; ty = lp.y
                        wm.updateViewLayout(t, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!dragged) {
                    main.post { enabled = !enabled; refresh() }
                }
            }
            true
        }
        wm.addView(t, lp)
        toggle = t
    }

    /** Makes the overlay touch-transparent, injects the gesture, then restores the overlay. */
    private fun inject(path: Path, ms: Long) {
        setCursorTouchable(false)
        main.postDelayed({
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
                .build()
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { setCursorTouchable(true) }
                override fun onCancelled(d: GestureDescription?) { setCursorTouchable(true) }
            }, main)
            if (!ok) setCursorTouchable(true)
        }, 60)
    }

    private fun setCursorTouchable(touchable: Boolean) {
        val v = cursor ?: return
        val lp = cursorLp ?: return
        if (!v.isAttachedToWindow) return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        wm.updateViewLayout(v, lp)
    }
}
