package com.dvereux.vcursor

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.hypot

class CursorService : AccessibilityService(), CursorView.Listener {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var cursor: CursorView? = null
    private var cursorLp: WindowManager.LayoutParams? = null
    private var toggle: TextView? = null
    private var diag: TextView? = null
    private val ver = "v3"
    private var enabled = true
    private var tx = 24
    private var ty = 24

    // Pointer / drag state
    private val slop = 16f
    private val delayMs = 20L
    private var tracking = false
    private var dragging = false
    private var ending = false
    private var busy = false
    private var lastCont = false
    private var startX = 0f
    private var startY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var pendX = 0f
    private var pendY = 0f
    private var downTime = 0L
    private var lastStroke: GestureDescription.StrokeDescription? = null

    override fun onServiceConnected() {
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addDiag()
        refresh()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        refresh()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        removeViews()
        diag?.let { runCatching { wm.removeView(it) } }
        diag = null
        super.onDestroy()
    }

    /** In landscape, swallow Back and Home presses that come from a mouse (right and middle click). */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        val k = event.keyCode
        val fromMouse = (event.source and InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE
        val consume = isLandscape() && fromMouse &&
            (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_HOME)
        if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_HOME ||
            k == KeyEvent.KEYCODE_APP_SWITCH || k == KeyEvent.KEYCODE_MENU || fromMouse) {
            val act = if (event.action == KeyEvent.ACTION_DOWN) "DOWN" else "UP"
            val dev = event.device?.name ?: "?"
            diag?.text = "$ver KEY $act ${KeyEvent.keyCodeToString(k)} " +
                "src=0x${Integer.toHexString(event.source)} mouse=$fromMouse " +
                "land=${isLandscape()} consumed=$consume dev=$dev"
        }
        return consume
    }

    private fun addDiag() {
        val t = TextView(this).apply {
            text = "$ver diag: waiting for Back/Home"
            setTextColor(Color.YELLOW)
            textSize = 10f
            setPadding(16, 8, 16, 8)
            setBackgroundColor(0xAA000000.toInt())
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = 8; y = 8 }
        wm.addView(t, lp)
        diag = t
    }

    private fun isLandscape() =
        resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private fun refresh() {
        removeViews()
        if (!isLandscape()) return
        if (enabled) addCursor()
        addToggle()   // added last so it stays on top
    }

    private fun removeViews() {
        cursor?.let { runCatching { wm.removeView(it) } }
        toggle?.let { runCatching { wm.removeView(it) } }
        cursor = null; cursorLp = null; toggle = null
        dragging = false; tracking = false; ending = false; busy = false; lastStroke = null
    }

    private fun addCursor() {
        val v = CursorView(this, this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(v, lp)
        cursor = v; cursorLp = lp
    }

    private fun addToggle() {
        val t = TextView(this).apply {
            text = if (enabled) "CURSOR ON $ver" else "CURSOR OFF $ver"
            setTextColor(Color.WHITE)
            textSize = 11f
            setPadding(28, 14, 28, 14)
            setBackgroundColor(if (enabled) 0xCC1B5E20.toInt() else 0xCC616161.toInt())
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = tx; y = ty }

        var downX = 0f; var downY = 0f; var sX = 0; var sY = 0; var dragged = false
        t.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    sX = lp.x; sY = lp.y; dragged = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (dragged || abs(dx) > 12 || abs(dy) > 12) {
                        dragged = true
                        lp.x = sX + dx.toInt(); lp.y = sY + dy.toInt()
                        tx = lp.x; ty = lp.y
                        wm.updateViewLayout(t, lp)
                    }
                }
                MotionEvent.ACTION_UP -> if (!dragged) {
                    main.post { enabled = !enabled; refresh() }
                }
            }
            true
        }
        wm.addView(t, lp)
        toggle = t
    }

    // ---- CursorView.Listener ----

    override fun onDown(x: Float, y: Float) {
        if (dragging) return
        tracking = true
        startX = x; startY = y
        pendX = x; pendY = y
        downTime = SystemClock.uptimeMillis()
    }

    override fun onMove(x: Float, y: Float) {
        if (!tracking) return
        pendX = x; pendY = y
        if (!dragging) {
            if (Build.VERSION.SDK_INT >= 26 && hypot(x - startX, y - startY) > slop) startDrag()
        } else if (!busy) {
            sendSegment()
        }
    }

    override fun onUp(x: Float, y: Float) {
        if (!tracking) return
        tracking = false
        pendX = x; pendY = y
        if (dragging) {
            ending = true
            if (!busy) sendSegment()
        } else if (hypot(x - startX, y - startY) > slop) {
            // Android 7.x fallback: replay the swipe on release.
            val p = Path().apply { moveTo(startX, startY); lineTo(x, y) }
            inject(p, (SystemClock.uptimeMillis() - downTime).coerceIn(80L, 1500L))
        } else {
            inject(Path().apply { moveTo(startX, startY) }, 50L)
        }
    }

    override fun onScroll(x: Float, y: Float, amount: Float) {
        if (dragging) return
        val maxY = resources.displayMetrics.heightPixels.toFloat()
        val p = Path().apply {
            moveTo(x, y)
            lineTo(x, (y + amount * 300f).coerceIn(0f, maxY))
        }
        inject(p, 150L)
    }

    // ---- Live drag (Android 8.0+): chained, continued strokes ----

    private fun startDrag() {
        dragging = true; ending = false; busy = true; lastCont = false
        lastStroke = null
        lastX = startX; lastY = startY
        setCursorTouchable(false)
        main.postDelayed({ if (dragging) sendSegment() }, delayMs)
    }

    private fun sendSegment() {
        val toX = pendX
        val toY = pendY
        val path = Path().apply {
            moveTo(lastX, lastY)
            if (toX != lastX || toY != lastY) lineTo(toX, toY)
        }
        val cont = !ending
        val prev = lastStroke
        val stroke = if (prev == null) {
            GestureDescription.StrokeDescription(path, 0L, 30L, cont)
        } else {
            prev.continueStroke(path, 0L, 30L, cont)
        }
        lastStroke = stroke
        lastCont = cont
        lastX = toX; lastY = toY
        busy = true
        val ok = dispatchGesture(
            GestureDescription.Builder().addStroke(stroke).build(),
            object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) {
                    busy = false
                    if (!dragging) return
                    if (ending) {
                        if (lastCont) sendSegment() else finishDrag()
                    } else if (pendX != lastX || pendY != lastY) {
                        sendSegment()
                    }
                }
                override fun onCancelled(d: GestureDescription?) { finishDrag() }
            },
            main
        )
        if (!ok) finishDrag()
    }

    private fun finishDrag() {
        dragging = false; ending = false; busy = false; tracking = false
        lastStroke = null
        setCursorTouchable(true)
    }

    // ---- One-shot gestures (taps, scroll) ----

    /** Makes the overlay touch-transparent, injects the gesture, then restores the overlay. */
    private fun inject(path: Path, ms: Long) {
        setCursorTouchable(false)
        main.postDelayed({
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, ms))
                .build()
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { if (!dragging) setCursorTouchable(true) }
                override fun onCancelled(d: GestureDescription?) { if (!dragging) setCursorTouchable(true) }
            }, main)
            if (!ok) setCursorTouchable(true)
        }, delayMs)
    }

    private fun setCursorTouchable(touchable: Boolean) {
        val v = cursor ?: return
        val lp = cursorLp ?: return
        if (!v.isAttachedToWindow) return
        lp.flags = if (touchable) {
            lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        wm.updateViewLayout(v, lp)
    }
}
