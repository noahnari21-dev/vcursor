package com.dvereux.vcursor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View

class CursorView(ctx: Context, private val listener: Listener) : View(ctx) {

    interface Listener {
        fun onDown(x: Float, y: Float)
        fun onMove(x: Float, y: Float)
        fun onUp(x: Float, y: Float)
        fun onScroll(x: Float, y: Float, amount: Float)
    }

    private var cx = 0f
    private var cy = 0f
    private var visible = false
    private var active = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
    }
    private val arrow = Path().apply {
        moveTo(0f, 0f); lineTo(0f, 17f); lineTo(4.5f, 13f); lineTo(7.5f, 20f)
        lineTo(10f, 19f); lineTo(7f, 12f); lineTo(12.5f, 12f); close()
    }

    override fun onDraw(c: Canvas) {
        if (!visible) return
        val d = resources.displayMetrics.density
        c.save()
        c.translate(cx, cy)
        c.scale(d, d)
        c.drawPath(arrow, fill)
        c.drawPath(arrow, edge)
        c.restore()
    }

    private fun moveCursor(x: Float, y: Float) {
        cx = x; cy = y; visible = true
        invalidate()
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.getToolType(0) != MotionEvent.TOOL_TYPE_MOUSE) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_HOVER_ENTER,
            MotionEvent.ACTION_HOVER_MOVE -> moveCursor(e.x, e.y)
            MotionEvent.ACTION_SCROLL -> {
                val v = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
                if (v != 0f) listener.onScroll(e.rawX, e.rawY, v)
            }
        }
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val mouse = e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE
        if (mouse) moveCursor(e.x, e.y)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // Right click and middle click are ignored by the overlay.
                val ignored = MotionEvent.BUTTON_SECONDARY or MotionEvent.BUTTON_TERTIARY
                if (mouse && (e.buttonState and ignored) != 0) {
                    active = false
                    return true
                }
                active = true
                listener.onDown(e.rawX, e.rawY)
            }
            MotionEvent.ACTION_MOVE -> if (active) listener.onMove(e.rawX, e.rawY)
            MotionEvent.ACTION_UP,
            MotionEvent.ACTION_CANCEL -> {
                if (active) listener.onUp(e.rawX, e.rawY)
                active = false
            }
        }
        return true
    }
}
