package com.dvereux.vcursor

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot

class CursorView(
    ctx: Context,
    private val onStroke: (Path, Long) -> Unit,
    private val onBack: () -> Unit
) : View(ctx) {

    private var cx = 0f
    private var cy = 0f
    private var visible = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
    }
    private val arrow = Path().apply {
        moveTo(0f, 0f); lineTo(0f, 17f); lineTo(4.5f, 13f); lineTo(7.5f, 20f)
        lineTo(10f, 19f); lineTo(7f, 12f); lineTo(12.5f, 12f); close()
    }

    private var stroke: Path? = null
    private var t0 = 0L
    private var sx = 0f
    private var sy = 0f
    private var moved = false

    override fun onDraw(c: Canvas) {
        if (!visible) return
        val d = resources.displayMetrics.density
        c.save()
        c.translate(cx, cy)
        c.scale(d, d)
        c.drawPath(arrow, fill)
        c.drawPath(arrow, edge)
        c.restore()
    }

    private fun moveTo(x: Float, y: Float) {
        cx = x; cy = y; visible = true
        invalidate()
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        if (e.getToolType(0) != MotionEvent.TOOL_TYPE_MOUSE) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_HOVER_ENTER,
            MotionEvent.ACTION_HOVER_MOVE -> moveTo(e.x, e.y)
            MotionEvent.ACTION_SCROLL -> {
                val v = e.getAxisValue(MotionEvent.AXIS_VSCROLL)
                if (v != 0f) {
                    val maxY = resources.displayMetrics.heightPixels.toFloat()
                    val p = Path().apply {
                        moveTo(e.rawX, e.rawY)
                        lineTo(e.rawX, (e.rawY + v * 300f).coerceIn(0f, maxY))
                    }
                    onStroke(p, 150L)
                }
            }
        }
        return true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val mouse = e.getToolType(0) == MotionEvent.TOOL_TYPE_MOUSE
        if (mouse) moveTo(e.x, e.y)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (mouse && (e.buttonState and MotionEvent.BUTTON_SECONDARY) != 0) {
                    stroke = null
                    onBack()
                    return true
                }
                stroke = Path().apply { moveTo(e.rawX, e.rawY) }
                sx = e.rawX; sy = e.rawY
                t0 = e.eventTime
                moved = false
            }
            MotionEvent.ACTION_MOVE -> stroke?.let {
                it.lineTo(e.rawX, e.rawY)
                if (hypot(e.rawX - sx, e.rawY - sy) > 16f) moved = true
            }
            MotionEvent.ACTION_UP -> stroke?.let {
                val dur = if (moved) (e.eventTime - t0).coerceIn(80L, 1500L) else 50L
                if (moved) it.lineTo(e.rawX, e.rawY)
                onStroke(it, dur)
            }
            MotionEvent.ACTION_CANCEL -> stroke = null
        }
        if (e.actionMasked == MotionEvent.ACTION_UP) stroke = null
        return true
    }
}
